
package GUI;

import DAO.Cliente;


public class Jcliente extends javax.swing.JPanel {

    
    Cliente objClien_Enc = new Cliente();
  
    public Jcliente() {
        initComponents();
    }

    public void limpar(){
        
      
      txtnomecliente.setText("");
      txtemailcliente.setText("");
      txtcpfcliente.setText("");
      txtendereçocliente.setText("");
      txtnumerocliente.setText("");
      txtcelularcliente.setText("");
      txttelefonecliente.setText("");
      txtcepcliente.setText("");
        
    }
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        PainelCliente = new javax.swing.JPanel();
        LabelCPFcliente = new javax.swing.JLabel();
        labelcliente = new javax.swing.JLabel();
        LabelNumerocliente = new javax.swing.JLabel();
        LabelCepcliente = new javax.swing.JLabel();
        LabelNomeclienteTitulo = new javax.swing.JLabel();
        LabelCelularcliente = new javax.swing.JLabel();
        txtnomecliente = new javax.swing.JTextField();
        txtendereçocliente = new javax.swing.JTextField();
        txtcelularcliente = new javax.swing.JFormattedTextField();
        txtcepcliente = new javax.swing.JFormattedTextField();
        txtnumerocliente = new javax.swing.JTextField();
        LabelEndereçocliente = new javax.swing.JLabel();
        txtConsultarCli = new javax.swing.JTextField();
        txtcpfcliente = new javax.swing.JFormattedTextField();
        LabelConsultarCli = new javax.swing.JLabel();
        txttelefonecliente = new javax.swing.JFormattedTextField();
        ButCadastrar = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        LabelNomecliente = new javax.swing.JLabel();
        LabelTelefonecliente1 = new javax.swing.JLabel();
        txtemailcliente = new javax.swing.JTextField();
        ButConsultar = new javax.swing.JButton();
        ButAtualizar = new javax.swing.JButton();

        PainelCliente.setBackground(new java.awt.Color(57, 137, 162));
        PainelCliente.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        LabelCPFcliente.setFont(new java.awt.Font("Yu Gothic UI", 1, 24)); // NOI18N
        LabelCPFcliente.setText("CPF:");
        PainelCliente.add(LabelCPFcliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 260, 60, 40));

        labelcliente.setFont(new java.awt.Font("Yu Gothic UI", 1, 18)); // NOI18N
        labelcliente.setText("Nº :");
        PainelCliente.add(labelcliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(840, 310, 70, 30));

        LabelNumerocliente.setFont(new java.awt.Font("Yu Gothic UI", 1, 24)); // NOI18N
        LabelNumerocliente.setText("Email:");
        PainelCliente.add(LabelNumerocliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 210, 70, 50));

        LabelCepcliente.setFont(new java.awt.Font("Yu Gothic UI", 1, 18)); // NOI18N
        LabelCepcliente.setText("CEP:");
        PainelCliente.add(LabelCepcliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 320, 60, 20));

        LabelNomeclienteTitulo.setFont(new java.awt.Font("Yu Gothic UI", 1, 36)); // NOI18N
        LabelNomeclienteTitulo.setText("Cliente");
        PainelCliente.add(LabelNomeclienteTitulo, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 30, 340, 80));

        LabelCelularcliente.setFont(new java.awt.Font("Yu Gothic UI", 1, 24)); // NOI18N
        LabelCelularcliente.setText("Celular:");
        PainelCliente.add(LabelCelularcliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 340, 110, 70));

        txtnomecliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtnomeclienteActionPerformed(evt);
            }
        });
        PainelCliente.add(txtnomecliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 180, 560, 30));

        txtendereçocliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtendereçoclienteActionPerformed(evt);
            }
        });
        PainelCliente.add(txtendereçocliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 310, 240, 30));

        try {
            txtcelularcliente.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("(##)#####-####")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        PainelCliente.add(txtcelularcliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 360, 180, 30));

        try {
            txtcepcliente.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("#####-###")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        PainelCliente.add(txtcepcliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 310, 110, 30));
        PainelCliente.add(txtnumerocliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(880, 310, 110, 30));

        LabelEndereçocliente.setFont(new java.awt.Font("Yu Gothic UI", 1, 24)); // NOI18N
        LabelEndereçocliente.setText("Endereço:");
        PainelCliente.add(LabelEndereçocliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 290, 110, 70));

        txtConsultarCli.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtConsultarCliActionPerformed(evt);
            }
        });
        PainelCliente.add(txtConsultarCli, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 480, 340, 30));

        try {
            txtcpfcliente.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("###.###.###-##")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        PainelCliente.add(txtcpfcliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 262, 560, 30));

        LabelConsultarCli.setFont(new java.awt.Font("Yu Gothic UI", 1, 24)); // NOI18N
        LabelConsultarCli.setText("Consultar:");
        PainelCliente.add(LabelConsultarCli, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 460, 110, 70));

        try {
            txttelefonecliente.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("(##)####-####")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        PainelCliente.add(txttelefonecliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 360, 250, 30));

        ButCadastrar.setBackground(new java.awt.Color(204, 204, 204));
        ButCadastrar.setFont(new java.awt.Font("Sitka Text", 1, 14)); // NOI18N
        ButCadastrar.setText("Cadastrar");
        ButCadastrar.setToolTipText("");
        ButCadastrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ButCadastrarActionPerformed(evt);
            }
        });
        PainelCliente.add(ButCadastrar, new org.netbeans.lib.awtextra.AbsoluteConstraints(800, 410, 164, 39));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMG/kisspng-hair-designs-unlimited-vector-graphics-barber-beau-heads-hairs-and-scissors-svg-png-icon-free-downloa-5b6e70bde64683.7954069415339644779432.png"))); // NOI18N
        PainelCliente.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 0, 250, 260));

        LabelNomecliente.setFont(new java.awt.Font("Yu Gothic UI", 1, 24)); // NOI18N
        LabelNomecliente.setText("Nome:");
        PainelCliente.add(LabelNomecliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 180, 90, 30));

        LabelTelefonecliente1.setFont(new java.awt.Font("Yu Gothic UI", 1, 24)); // NOI18N
        LabelTelefonecliente1.setText("Telefone:");
        PainelCliente.add(LabelTelefonecliente1, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 340, 110, 70));

        txtemailcliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtemailclienteActionPerformed(evt);
            }
        });
        PainelCliente.add(txtemailcliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 220, 560, 30));

        ButConsultar.setBackground(new java.awt.Color(204, 204, 204));
        ButConsultar.setFont(new java.awt.Font("Sitka Text", 1, 14)); // NOI18N
        ButConsultar.setText("Consultar");
        ButConsultar.setToolTipText("");
        ButConsultar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ButConsultarActionPerformed(evt);
            }
        });
        PainelCliente.add(ButConsultar, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 520, 164, 39));

        ButAtualizar.setBackground(new java.awt.Color(204, 204, 204));
        ButAtualizar.setFont(new java.awt.Font("Sitka Text", 1, 14)); // NOI18N
        ButAtualizar.setText("Atualizar");
        ButAtualizar.setToolTipText("");
        ButAtualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ButAtualizarActionPerformed(evt);
            }
        });
        PainelCliente.add(ButAtualizar, new org.netbeans.lib.awtextra.AbsoluteConstraints(790, 520, 164, 39));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(PainelCliente, javax.swing.GroupLayout.DEFAULT_SIZE, 1303, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(PainelCliente, javax.swing.GroupLayout.DEFAULT_SIZE, 804, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents

    private void ButCadastrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ButCadastrarActionPerformed

        objClien_Enc.setNome(txtnomecliente.getText());
        objClien_Enc.setEmail(txtemailcliente.getText());
        objClien_Enc.setCPF(txtcpfcliente.getText());
        objClien_Enc.setEndereço(txtendereçocliente.getText());
        objClien_Enc.setCEP(txtcepcliente.getText());
        objClien_Enc.setNumero(txtnumerocliente.getText());
        objClien_Enc.setTelefone(txttelefonecliente.getText());
        objClien_Enc.setCelular(txtcelularcliente.getText());
        objClien_Enc.insereCliente();

        
        limpar();
        // TODO add your handling code here:
    }//GEN-LAST:event_ButCadastrarActionPerformed

    private void txtConsultarCliActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtConsultarCliActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtConsultarCliActionPerformed

    private void txtendereçoclienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtendereçoclienteActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtendereçoclienteActionPerformed

    private void txtnomeclienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtnomeclienteActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtnomeclienteActionPerformed

    private void txtemailclienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtemailclienteActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtemailclienteActionPerformed

    private void ButConsultarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ButConsultarActionPerformed
              
        objClien_Enc.setID_Cli(Integer.parseInt(txtConsultarCli.getText()));
        
        objClien_Enc.consultaClientePorID();
        
        txtnomecliente.setText(objClien_Enc.getNome());
        txtemailcliente.setText(objClien_Enc.getEmail());
        txtcpfcliente.setText(objClien_Enc.getCPF());
        txtendereçocliente.setText(objClien_Enc.getEndereço());
        txtcepcliente.setText(objClien_Enc.getCEP());
        txtnumerocliente.setText(objClien_Enc.getNumero());
        txttelefonecliente.setText(objClien_Enc.getTelefone());
        txtcelularcliente.setText(objClien_Enc.getCelular());
               
        
        
        
    }//GEN-LAST:event_ButConsultarActionPerformed

    private void ButAtualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ButAtualizarActionPerformed

        try{
              objClien_Enc.setNome(txtnomecliente.getText());
              objClien_Enc.setEmail(txtemailcliente.getText());
              objClien_Enc.setCPF(txtcpfcliente.getText());
              objClien_Enc.setEndereço(txtendereçocliente.getText());
              objClien_Enc.setCEP(txtcepcliente.getText());
              objClien_Enc.setNumero(txtnumerocliente.getText());
              objClien_Enc.setTelefone(txttelefonecliente.getText());
              objClien_Enc.setCelular(txtcelularcliente.getText());
              
             objClien_Enc.setID_Cli(Integer.parseInt(txtConsultarCli.getText()));
    
            objClien_Enc.alterarCliente();
     
            limpar();
                
}    catch(Exception e1){
    e1.printStackTrace();
}        
                        
            
        
    }//GEN-LAST:event_ButAtualizarActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton ButAtualizar;
    private javax.swing.JButton ButCadastrar;
    private javax.swing.JButton ButConsultar;
    private javax.swing.JLabel LabelCPFcliente;
    private javax.swing.JLabel LabelCelularcliente;
    private javax.swing.JLabel LabelCepcliente;
    private javax.swing.JLabel LabelConsultarCli;
    private javax.swing.JLabel LabelEndereçocliente;
    private javax.swing.JLabel LabelNomecliente;
    private javax.swing.JLabel LabelNomeclienteTitulo;
    private javax.swing.JLabel LabelNumerocliente;
    private javax.swing.JLabel LabelTelefonecliente1;
    private javax.swing.JPanel PainelCliente;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel labelcliente;
    private javax.swing.JTextField txtConsultarCli;
    private javax.swing.JFormattedTextField txtcelularcliente;
    private javax.swing.JFormattedTextField txtcepcliente;
    private javax.swing.JFormattedTextField txtcpfcliente;
    private javax.swing.JTextField txtemailcliente;
    private javax.swing.JTextField txtendereçocliente;
    private javax.swing.JTextField txtnomecliente;
    private javax.swing.JTextField txtnumerocliente;
    private javax.swing.JFormattedTextField txttelefonecliente;
    // End of variables declaration//GEN-END:variables
}
