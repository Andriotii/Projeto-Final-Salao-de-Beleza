
package GUI;

import DAO.Cargo;
import DAO.Funcionario;
import java.awt.CardLayout;



public class JFuncionario extends javax.swing.JPanel {

    
 Funcionario objFunc_Enc = new Funcionario();
 
    Cargo objCargo_Enc = new Cargo();
    
    public JFuncionario() {
        initComponents();
        
      objCargo_Enc.preencherComboCargo(jCboCargo);
    } 
    
    
    
    public void limpar(){
        
      
      txtnomefuncionario.setText("");
      txtemailfuncionario.setText("");
      txtcpffuncionario.setText("");
      txtendereçofuncionario.setText("");
      txtnumerofuncionario.setText("");
      txtcelularfuncionario.setText("");
      txtcepfuncionario.setText("");
      txttelefonefuncionario.setText("");
        
    }
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        LabelCPF = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        LabelNumero = new javax.swing.JLabel();
        LabelCep = new javax.swing.JLabel();
        LabelConsuFuncionario = new javax.swing.JLabel();
        LabelCelular = new javax.swing.JLabel();
        txtConsulFuncionario = new javax.swing.JTextField();
        txtendereçofuncionario = new javax.swing.JTextField();
        txtcelularfuncionario = new javax.swing.JFormattedTextField();
        txtcepfuncionario = new javax.swing.JFormattedTextField();
        txtnumerofuncionario = new javax.swing.JTextField();
        LabelEndereço1 = new javax.swing.JLabel();
        txtemailfuncionario = new javax.swing.JTextField();
        txtcpffuncionario = new javax.swing.JFormattedTextField();
        LabelTelefone1 = new javax.swing.JLabel();
        txttelefonefuncionario = new javax.swing.JFormattedTextField();
        ButConsultar = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        LabelNomefuncionarioTitulo1 = new javax.swing.JLabel();
        LabelCargo = new javax.swing.JLabel();
        txtnomefuncionario = new javax.swing.JTextField();
        ButCadastrar = new javax.swing.JButton();
        LabelNome1 = new javax.swing.JLabel();
        jCboCargo = new javax.swing.JComboBox<>();
        ButInativar = new javax.swing.JButton();
        ButAtualizar = new javax.swing.JButton();
        Butativar = new javax.swing.JButton();
        Butaddcargo = new javax.swing.JButton();
        LabelNomeclienteTitulo = new javax.swing.JLabel();

        setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(57, 137, 162));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        LabelCPF.setFont(new java.awt.Font("Yu Gothic UI", 1, 24)); // NOI18N
        LabelCPF.setText("CPF:");
        jPanel1.add(LabelCPF, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 260, 60, 40));

        jLabel2.setFont(new java.awt.Font("Yu Gothic UI", 1, 18)); // NOI18N
        jLabel2.setText("Nº :");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(840, 310, 70, 30));

        LabelNumero.setFont(new java.awt.Font("Yu Gothic UI", 1, 24)); // NOI18N
        LabelNumero.setText("Email:");
        jPanel1.add(LabelNumero, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 210, 70, 50));

        LabelCep.setFont(new java.awt.Font("Yu Gothic UI", 1, 18)); // NOI18N
        LabelCep.setText("CEP:");
        jPanel1.add(LabelCep, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 320, 60, 20));

        LabelConsuFuncionario.setFont(new java.awt.Font("Yu Gothic UI", 1, 24)); // NOI18N
        LabelConsuFuncionario.setText("Consultar Funcionario:");
        jPanel1.add(LabelConsuFuncionario, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 540, 260, 30));

        LabelCelular.setFont(new java.awt.Font("Yu Gothic UI", 1, 24)); // NOI18N
        LabelCelular.setText("Celular:");
        jPanel1.add(LabelCelular, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 340, 110, 70));

        txtConsulFuncionario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtConsulFuncionarioActionPerformed(evt);
            }
        });
        jPanel1.add(txtConsulFuncionario, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 540, 360, 30));

        txtendereçofuncionario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtendereçofuncionarioActionPerformed(evt);
            }
        });
        jPanel1.add(txtendereçofuncionario, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 310, 240, 30));

        try {
            txtcelularfuncionario.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("(##)#####-####")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        jPanel1.add(txtcelularfuncionario, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 360, 180, 30));

        try {
            txtcepfuncionario.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("#####-###")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        jPanel1.add(txtcepfuncionario, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 310, 110, 30));
        jPanel1.add(txtnumerofuncionario, new org.netbeans.lib.awtextra.AbsoluteConstraints(880, 310, 110, 30));

        LabelEndereço1.setFont(new java.awt.Font("Yu Gothic UI", 1, 24)); // NOI18N
        LabelEndereço1.setText("Endereço:");
        jPanel1.add(LabelEndereço1, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 290, 110, 70));

        txtemailfuncionario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtemailfuncionarioActionPerformed(evt);
            }
        });
        jPanel1.add(txtemailfuncionario, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 220, 560, 30));

        try {
            txtcpffuncionario.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("###.###.###-##")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        jPanel1.add(txtcpffuncionario, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 262, 560, 30));

        LabelTelefone1.setFont(new java.awt.Font("Yu Gothic UI", 1, 24)); // NOI18N
        LabelTelefone1.setText("Telefone:");
        jPanel1.add(LabelTelefone1, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 340, 110, 70));

        try {
            txttelefonefuncionario.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("(##)####-####")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        jPanel1.add(txttelefonefuncionario, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 360, 250, 30));

        ButConsultar.setBackground(new java.awt.Color(204, 204, 204));
        ButConsultar.setFont(new java.awt.Font("Sitka Text", 1, 14)); // NOI18N
        ButConsultar.setText("Consultar");
        ButConsultar.setToolTipText("");
        ButConsultar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ButConsultarActionPerformed(evt);
            }
        });
        jPanel1.add(ButConsultar, new org.netbeans.lib.awtextra.AbsoluteConstraints(820, 590, 164, 39));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMG/kisspng-hair-designs-unlimited-vector-graphics-barber-beau-heads-hairs-and-scissors-svg-png-icon-free-downloa-5b6e70bde64683.7954069415339644779432.png"))); // NOI18N
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 80, 240, 210));

        LabelNomefuncionarioTitulo1.setFont(new java.awt.Font("Yu Gothic UI", 1, 36)); // NOI18N
        LabelNomefuncionarioTitulo1.setText("Funcionario");
        jPanel1.add(LabelNomefuncionarioTitulo1, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 30, 340, 80));

        LabelCargo.setFont(new java.awt.Font("Yu Gothic UI", 1, 24)); // NOI18N
        LabelCargo.setText("Cargo");
        jPanel1.add(LabelCargo, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 440, 90, 30));

        txtnomefuncionario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtnomefuncionarioActionPerformed(evt);
            }
        });
        jPanel1.add(txtnomefuncionario, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 180, 560, 30));

        ButCadastrar.setBackground(new java.awt.Color(204, 204, 204));
        ButCadastrar.setFont(new java.awt.Font("Sitka Text", 1, 14)); // NOI18N
        ButCadastrar.setText("Cadastrar");
        ButCadastrar.setToolTipText("");
        ButCadastrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ButCadastrarActionPerformed(evt);
            }
        });
        jPanel1.add(ButCadastrar, new org.netbeans.lib.awtextra.AbsoluteConstraints(840, 430, 164, 39));

        LabelNome1.setFont(new java.awt.Font("Yu Gothic UI", 1, 24)); // NOI18N
        LabelNome1.setText("Nome:");
        jPanel1.add(LabelNome1, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 170, 90, 30));

        jCboCargo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCboCargoActionPerformed(evt);
            }
        });
        jPanel1.add(jCboCargo, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 440, 160, -1));

        ButInativar.setBackground(new java.awt.Color(204, 204, 204));
        ButInativar.setFont(new java.awt.Font("Sitka Text", 1, 14)); // NOI18N
        ButInativar.setText("Inativar");
        ButInativar.setToolTipText("");
        ButInativar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ButInativarActionPerformed(evt);
            }
        });
        jPanel1.add(ButInativar, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 650, 164, 39));

        ButAtualizar.setBackground(new java.awt.Color(204, 204, 204));
        ButAtualizar.setFont(new java.awt.Font("Sitka Text", 1, 14)); // NOI18N
        ButAtualizar.setText("Atualizar");
        ButAtualizar.setToolTipText("");
        ButAtualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ButAtualizarActionPerformed(evt);
            }
        });
        jPanel1.add(ButAtualizar, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 590, 164, 39));

        Butativar.setBackground(new java.awt.Color(204, 204, 204));
        Butativar.setFont(new java.awt.Font("Sitka Text", 1, 14)); // NOI18N
        Butativar.setText("Ativar");
        Butativar.setToolTipText("");
        Butativar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ButativarActionPerformed(evt);
            }
        });
        jPanel1.add(Butativar, new org.netbeans.lib.awtextra.AbsoluteConstraints(820, 650, 164, 39));

        Butaddcargo.setBackground(new java.awt.Color(204, 204, 204));
        Butaddcargo.setFont(new java.awt.Font("Sitka Text", 1, 14)); // NOI18N
        Butaddcargo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMG/icons8-mais-50.png"))); // NOI18N
        Butaddcargo.setText("Adicionar Cargo");
        Butaddcargo.setToolTipText("");
        Butaddcargo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ButaddcargoActionPerformed(evt);
            }
        });
        jPanel1.add(Butaddcargo, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 430, 220, 50));

        add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1240, 840));

        LabelNomeclienteTitulo.setFont(new java.awt.Font("Yu Gothic UI", 1, 36)); // NOI18N
        LabelNomeclienteTitulo.setText("Cliente");
        add(LabelNomeclienteTitulo, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 30, 340, 80));
    }// </editor-fold>//GEN-END:initComponents

    private void txtConsulFuncionarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtConsulFuncionarioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtConsulFuncionarioActionPerformed

    private void txtendereçofuncionarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtendereçofuncionarioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtendereçofuncionarioActionPerformed

    private void txtemailfuncionarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtemailfuncionarioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtemailfuncionarioActionPerformed

    private void ButConsultarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ButConsultarActionPerformed

       objFunc_Enc.setID_Func(Integer.parseInt(txtConsulFuncionario.getText()));
       
       objFunc_Enc.consultaFuncPorId();
       
      txtnomefuncionario.setText(objFunc_Enc.getNome());
      txtemailfuncionario.setText(objFunc_Enc.getEmail());
      txtcpffuncionario.setText(objFunc_Enc.getCPF());
      txtendereçofuncionario.setText(objFunc_Enc.getEndereço());
      txtnumerofuncionario.setText(objFunc_Enc.getNumero());
      txtcelularfuncionario.setText(objFunc_Enc.getCelular());
     txtcepfuncionario.setText(objFunc_Enc.getCEP());
     txttelefonefuncionario.setText(objFunc_Enc.getTelefone());
     
      
        
       
    }//GEN-LAST:event_ButConsultarActionPerformed

    private void txtnomefuncionarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtnomefuncionarioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtnomefuncionarioActionPerformed

    private void ButCadastrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ButCadastrarActionPerformed
     objFunc_Enc.setNome(txtnomefuncionario.getText());
     objFunc_Enc.setEmail(txtemailfuncionario.getText()); 
     objFunc_Enc.setCPF(txtcpffuncionario.getText());
     objFunc_Enc.setEndereço(txtendereçofuncionario.getText());
     objFunc_Enc.setNumero(txtnumerofuncionario.getText());
     objFunc_Enc.setCelular(txtcelularfuncionario.getText());
     objFunc_Enc.setCEP(txtcepfuncionario.getText());
     objFunc_Enc.setTelefone(txttelefonefuncionario.getText());
     
     objFunc_Enc.setID_cargofk(Integer.parseInt(String.valueOf(jCboCargo.getSelectedItem()).substring(0, jCboCargo.getSelectedItem().toString().indexOf(" -"))));
     
     objFunc_Enc.insereFuncionario();       
     
        limpar();

     
     
    }//GEN-LAST:event_ButCadastrarActionPerformed

    private void ButInativarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ButInativarActionPerformed

          objFunc_Enc.setID_Func(Integer.parseInt(txtConsulFuncionario.getText()));
       
          objFunc_Enc.intativaFuncionario();
                limpar();

    // TODO add your handling code here:
    }//GEN-LAST:event_ButInativarActionPerformed

    private void jCboCargoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCboCargoActionPerformed

        
        
        
        
        

    }//GEN-LAST:event_jCboCargoActionPerformed

    private void ButAtualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ButAtualizarActionPerformed

        try{
     objFunc_Enc.setNome(txtnomefuncionario.getText());
     objFunc_Enc.setEmail(txtemailfuncionario.getText()); 
     objFunc_Enc.setCPF(txtcpffuncionario.getText());
     objFunc_Enc.setEndereço(txtendereçofuncionario.getText());
     objFunc_Enc.setNumero(txtnumerofuncionario.getText());
     objFunc_Enc.setCelular(txtcelularfuncionario.getText());
     objFunc_Enc.setCEP(txtcepfuncionario.getText());
     objFunc_Enc.setTelefone(txttelefonefuncionario.getText());
     
     
     objFunc_Enc.setID_Func(Integer.parseInt(txtConsulFuncionario.getText()));
    objFunc_Enc.alterarFuncionario();
        
}    catch(Exception e1){
    e1.printStackTrace();
}    
        
       
       
    }//GEN-LAST:event_ButAtualizarActionPerformed

    private void ButativarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ButativarActionPerformed


    objFunc_Enc.setID_Func(Integer.parseInt(txtConsulFuncionario.getText()));
       
       objFunc_Enc.ativarFuncionario();

               limpar();

    }//GEN-LAST:event_ButativarActionPerformed

    private void ButaddcargoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ButaddcargoActionPerformed

        NovoCargo objCargo = new NovoCargo();         

        objCargo.setVisible(true);
        
        
        // TODO add your handling code here:
    }//GEN-LAST:event_ButaddcargoActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton ButAtualizar;
    private javax.swing.JButton ButCadastrar;
    private javax.swing.JButton ButConsultar;
    private javax.swing.JButton ButInativar;
    private javax.swing.JButton Butaddcargo;
    private javax.swing.JButton Butativar;
    private javax.swing.JLabel LabelCPF;
    private javax.swing.JLabel LabelCargo;
    private javax.swing.JLabel LabelCelular;
    private javax.swing.JLabel LabelCep;
    private javax.swing.JLabel LabelConsuFuncionario;
    private javax.swing.JLabel LabelEndereço1;
    private javax.swing.JLabel LabelNome1;
    private javax.swing.JLabel LabelNomeclienteTitulo;
    private javax.swing.JLabel LabelNomefuncionarioTitulo1;
    private javax.swing.JLabel LabelNumero;
    private javax.swing.JLabel LabelTelefone1;
    private javax.swing.JComboBox<String> jCboCargo;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField txtConsulFuncionario;
    private javax.swing.JFormattedTextField txtcelularfuncionario;
    private javax.swing.JFormattedTextField txtcepfuncionario;
    private javax.swing.JFormattedTextField txtcpffuncionario;
    private javax.swing.JTextField txtemailfuncionario;
    private javax.swing.JTextField txtendereçofuncionario;
    private javax.swing.JTextField txtnomefuncionario;
    private javax.swing.JTextField txtnumerofuncionario;
    private javax.swing.JFormattedTextField txttelefonefuncionario;
    // End of variables declaration//GEN-END:variables
}
