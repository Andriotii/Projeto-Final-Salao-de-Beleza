
package DAO;



import java.sql.PreparedStatement;
import  UTIL.Conexao;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;



public class Cliente {
 
    private PreparedStatement statement;
    private static ResultSet rs;

private int ID_Cli;
private String nome;
private String email;
private String CPF;
private String Endereço;
private String Numero;
private String Telefone;
private String Celular;
 private String CEP;
    
     
     
     Connection conexao = new Conexao().getConnection();
     
     
      public int getID_Cli() {
        return ID_Cli;
    }

    public void setID_Cli(int ID_Cli) {
        this.ID_Cli = ID_Cli;
    }
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getCPF() {
        return CPF;
    }

    public void setCPF(String CPF) {
        this.CPF = CPF;
    }

    public String getEndereço() {
        return Endereço;
    }

    public void setEndereço(String Endereço) {
        this.Endereço = Endereço;
    }

    public String getNumero() {
        return Numero;
    }

    public void setNumero(String Numero) {
        this.Numero = Numero;
    }

    public String getTelefone() {
        return Telefone;
    }

    public void setTelefone(String Telefone) {
        this.Telefone = Telefone;
    }

    public String getCelular() {
        return Celular;
    }

    public void setCelular(String Celular) {
        this.Celular = Celular;
    }

    public String getCEP() {
        return CEP;
    }

    public void setCEP(String CEP) {
        this.CEP = CEP;
    }
     

      public void insereCliente(){
        
       try {
           
          String sql = "INSERT into cliente ( nome_clien, email_clien, cpf_clien, endereco_clien, numero_clien, cep_clien, celular_clien, telefone_clien) VALUES(?,?,?,?,?,?,?,?)";
          
          
        statement = conexao.prepareStatement(sql);
          statement.setString(1, getNome());
          statement.setString(2, getEmail());
          statement.setString(3, getCPF());
          statement.setString(4, getEndereço());
          statement.setString(5, getNumero());
          statement.setString(6, getCEP());
          statement.setString(7, getCelular());
          statement.setString(8, getTelefone());
          
          statement.execute();
          statement.close();
          
            
                
                
       } catch(SQLException e1){
        e1.printStackTrace();
    }
       JOptionPane.showMessageDialog(null,"Cadastrado com Sucesso ");
     
       
       
    }
      
      
      public void consultaClientePorID() {

try{
String sql = "select * from cliente where ID_Cli  = ? ";

    statement = conexao.prepareStatement(sql);
    statement.setInt(1, getID_Cli());
    
    rs = statement.executeQuery();

if(rs.next()){

setID_Cli(rs.getInt(1));
setNome(rs.getString(2));
setEmail(rs.getString(3));
setCPF( rs.getString(4));
setEndereço( rs.getString(5));
setNumero(rs.getString(6));
setCEP(rs.getString(7));
setCelular(rs.getString(8));
setTelefone(rs.getString(9));

 


}  else{

JOptionPane.showMessageDialog(null, "Codigo não encontrado");
    
}

    rs.close();
        statement.close();
} catch (SQLException e){
            e.printStackTrace();


}
      }
        public void alterarCliente(){
        
       try {
           
          String sql = "update  cliente set nome_clien = ?, email_clien = ?, cpf_clien = ?, endereco_clien = ?, numero_clien = ?, cep_clien = ?, celular_clien = ?, telefone_clien = ? where ID_Cli = ?";
          
        statement = conexao.prepareStatement(sql);
         
          statement.setString(1, getNome());
          statement.setString(2, getEmail());
          statement.setString(3, getCPF());
          statement.setString(4, getEndereço());
          statement.setString(5, getNumero());
          statement.setString(6, getCEP());
          statement.setString(7, getCelular());
          statement.setString(8, getTelefone());
          statement.setInt(9, getID_Cli());
          
          
          statement.execute();
          statement.close();
            
            JOptionPane.showMessageDialog(null, "Atualizado com sucesso!!!");
            
       } catch (SQLException e1) {
           e1.printStackTrace();
           
       }
  
        }
}
