package DAO;


import java.sql.PreparedStatement;
import  UTIL.Conexao;
import java.sql.Connection;
import java.sql.SQLException;
import javax.swing.JOptionPane;

import java.sql.ResultSet;


public class Funcionario {

 private PreparedStatement statement;

  
 private static ResultSet rs;
 

private String nome;
private String email;
private String CPF;
private String Endereço;
private String Numero;
private String Telefone;
private String Celular;
 private String CEP;
 private int ID_Func;

private int ID_cargofk;

 
    


Connection conexao = new Conexao().getConnection();

    public int getID_cargofk() {
        return ID_cargofk;
    }

    public void setID_cargofk(int ID_cargofk) {
        this.ID_cargofk = ID_cargofk;
    }
   public int getID_Func() {
        return ID_Func;
    }

    public void setID_Func(int ID_Func) {
        this.ID_Func = ID_Func;
    }
 


    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
       
        public String getCPF() {
        return CPF;
    }

    public void setCPF(String CPF) {
        this.CPF = CPF;
    }

    public String getEndereço() {
        return Endereço;
    }

    public void setEndereço(String Endereço) {
        this.Endereço = Endereço;
    }

    public String getNumero() {
        return Numero;
    }

    public void setNumero(String Numero) {
        this.Numero = Numero;
    }

    public String getTelefone() {
        return Telefone;
    }

    public void setTelefone(String Telefone) {
        this.Telefone = Telefone;
    }

    public String getCelular() {
        return Celular;
    }

    public void setCelular(String Celular) {
        this.Celular = Celular;
    }

    public String getCEP() {
        return CEP;
    }

    public void setCEP(String CEP) {
        this.CEP = CEP;
    }

    public void insereFuncionario(){
        
       try {
           
          String sql = "INSERT into funcionario (nome_func, email_func, cpf_Func, endereco_func, numero_func, cep_func, celular_func, telefone_func, ID_CARGOFK) VALUES(?,?,?,?,?,?,?,?, ?)";
           
          
        statement = conexao.prepareStatement(sql);
         
          statement.setString(1, getNome());
          statement.setString(2, getEmail());
          statement.setString(3, getCPF());
          statement.setString(4, getEndereço());
          statement.setString(5, getNumero());
          statement.setString(6, getCEP());
          statement.setString(7, getCelular());
          statement.setString(8, getTelefone());
          statement.setInt(9, getID_cargofk());
          
          statement.execute();
          statement.close();
          
            
                
                
       } catch(SQLException e1){
        e1.printStackTrace();
    }
       JOptionPane.showMessageDialog(null,"Cadastrado com Sucesso ");
     
        
        
    }
    public void consultaFuncPorId() {

try{
String sql = "select * from funcionario where ID_Func = ?  and status = 1";

    statement = conexao.prepareStatement(sql);
    statement.setInt(1, getID_Func());
    
    rs =     statement.executeQuery();

if(rs.next()){

setID_Func( rs.getInt(1));
setNome(rs.getString(2));
setEmail(rs.getString(3));
setCPF( rs.getString(4));
setEndereço( rs.getString(5));
setNumero(rs.getString(6));
setCEP(rs.getString(7));
setCelular(rs.getString(8));
setTelefone(rs.getString(9));

 


}  else{

JOptionPane.showMessageDialog(null, "Codigo não encontrado");
    
}

    rs.close();
        statement.close();
} catch (SQLException e){
            e.printStackTrace();
}
   

}
    public void alterarFuncionario(){
        
       try {
           
          String sql = "update  funcionario set nome_func = ?, email_func = ?, cpf_Func = ?, endereco_func = ?, numero_func = ?, cep_func = ?, celular_func = ?, telefone_func = ?,  where ID_Func = ?";
          
        statement = conexao.prepareStatement(sql);
         
          statement.setString(1, getNome());
          statement.setString(2, getEmail());
          statement.setString(3, getCPF());
          statement.setString(4, getEndereço());
          statement.setString(5, getNumero());
          statement.setString(6, getCEP());
          statement.setString(7, getCelular());
          statement.setString(8, getTelefone());
          statement.setInt(9, getID_Func());
          
          statement.execute();
          statement.close();
            
            JOptionPane.showMessageDialog(null, "Atualizado com sucesso!!!");
            
       } catch (SQLException e1) {
           e1.printStackTrace();
           
       }
    }
       public void intativaFuncionario(){
        
       try {
           
          String sql = "update  funcionario set  status = 0 where ID_Func = ?";
          
        statement = conexao.prepareStatement(sql);
         
          

          statement.setInt(1, getID_Func());
          
          statement.execute();
          statement.close();
            
            JOptionPane.showMessageDialog(null, "Inativado com sucesso!!!");
            
       } catch (SQLException e1) {
           e1.printStackTrace();
           
       }
       }
             public void ativarFuncionario(){
        
       try {
           
          String sql = "update  funcionario set  status = 1 where ID_Func = ?";
          
        statement = conexao.prepareStatement(sql);
         
          

          statement.setInt(1, getID_Func());
          
          statement.execute();
          statement.close();
            
            JOptionPane.showMessageDialog(null, "Ativado com sucesso!!!");
            
       } catch (SQLException e1) {
           e1.printStackTrace();
           
       }
  }
}

        




