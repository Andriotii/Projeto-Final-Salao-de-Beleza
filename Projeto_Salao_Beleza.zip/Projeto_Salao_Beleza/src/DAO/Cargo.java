
package DAO;

import java.sql.PreparedStatement;
import  UTIL.Conexao;
import java.sql.Connection;
import java.sql.SQLException;
import javax.swing.JOptionPane;

import java.sql.ResultSet;

public class Cargo {




private PreparedStatement statement;
private static ResultSet rs;


private int ID_CARGO;
private String NOME_CARGO;
private String SALARIO;

Connection conexao = new Conexao().getConnection();

    public int getID_CARGO() {
        return ID_CARGO;
    }

    public void setID_CARGO(int ID_CARGO) {
        this.ID_CARGO = ID_CARGO;
    }

    public String getNOME_CARGO() {
        return NOME_CARGO;
    }

    public void setNOME_CARGO(String NOME_CARGO) {
        this.NOME_CARGO = NOME_CARGO;
    }

    public String getSALARIO() {
        return SALARIO;
    }

    public void setSALARIO(String SALARIO) {
        this.SALARIO = SALARIO;
    }



public void preencherComboCargo(javax.swing.JComboBox cargoCombo){
    
    try{
            String sql = "SELECT * FROM CARGO";
            statement = conexao.prepareStatement(sql);
            rs = statement.executeQuery();
        while (rs.next()){
            
            cargoCombo.addItem(rs.getInt("ID_CARGO") + " - " + rs.getString("NOME_CARGO"));
        }
        
        conexao.close();
        statement = null;
        rs = null;
        
        
        
    } catch(SQLException e){
        
        e.printStackTrace();
        
    }
    
}

public void cadastrarCargo(){
    
    
     try {
           
          String sql = "INSERT into cargo (NOME_CARGO, SALARIO) VALUES(?,?)";
           
          
        statement = conexao.prepareStatement(sql);
         
          statement.setString(1, getNOME_CARGO());
          statement.setString(2, getSALARIO());
          
          
          statement.execute();
          statement.close();
          
            
                
                
       } catch(SQLException e1){
        e1.printStackTrace();
    }
       JOptionPane.showMessageDialog(null,"Cadastrado com Sucesso ");
     
        
        
    }
    
    
    
}


    

