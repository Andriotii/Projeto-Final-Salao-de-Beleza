package DAO;



import java.sql.PreparedStatement;
import  UTIL.Conexao;
import java.sql.Connection;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class Produto {
 
    private PreparedStatement statement;

     
private String Produto;
private String Marca;
private String Cor;
private String Quantidade;

Connection conexao = new Conexao().getConnection();

    public String getProduto() {
        return Produto;
    }

    public void setProduto(String Produto) {
        this.Produto = Produto;
    }

    public String getMarca() {
        return Marca;
    }

    public void setMarca(String Marca) {
        this.Marca = Marca;
    }

    public String getCor() {
        return Cor;
    }

    public void setCor(String Cor) {
        this.Cor = Cor;
    }

    public String getQuantidade() {
        return Quantidade;
    }

    public void setQuantidade(String Quantidade) {
        this.Quantidade = Quantidade;
    }

     

      public void insereCliente(){
        
       try {
           
          String sql = "INSERT into produto ( produto, marca_prod, cor_prod, quantidade_prod) VALUE(?, ?, ?, ? )";
          
          
        statement = conexao.prepareStatement(sql);
        
          statement.setString(1, getProduto());
          statement.setString(2, getMarca());
          statement.setString(3, getCor());
          statement.setString(4, getQuantidade());
         
          
          statement.execute();
          statement.close();
          
            
                
                
       } catch(SQLException e1){
        e1.printStackTrace();
    }
       JOptionPane.showMessageDialog(null,"Cadastrado com Sucesso ");
     
        
        
    }
}
