
package DAO;

import UTIL.Conexao;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;


public class Agenda extends  Cliente {
    
    
    
    Connection conexao = new Conexao().getConnection();
    
     private PreparedStatement statement;
    private static ResultSet rs;
    
    private int ID_Agenda;
    private String horario;
    private Date data;
    private String observação;
    private int ID_cargofk;
    
    public int getID_Agenda() {
        return ID_Agenda;
    }

    public void setID_Agenda(int ID_Agenda) {
        this.ID_Agenda = ID_Agenda;
    }
    

    public String getHorario() {
        return horario;
    }

    public void setHorario(String horario) {
        this.horario = horario;
    }

    public Date getData() {
        return data;
    }

    public void setData(Date data) {
        this.data = data;
    }

    public String getObservação() {
        return observação;
    }

    public void setObservação(String observação) {
        this.observação = observação;
    }
    
  public int getID_cargofk() {
        return ID_cargofk;
    }

    public void setID_cargofk(int ID_cargofk) {
        this.ID_cargofk = ID_cargofk;
    }
 
   
 public void insereAgenda(){
        
       try {
           
          String sql = "INSERT into agenda (Nome_Cli, CPF_Cli , Data_Agenda, horario,agenda_FunFk, agenda_Clifk ) VALUES(?,?,?,?,?,?)";
           
          
        statement = conexao.prepareStatement(sql);
         
          statement.setString(1, getNome());
          statement.setString(2, getCPF());
          statement.setDate(3, getData());
          statement.setString(4, getHorario());
          statement.setInt(5, getID_cargofk());
          statement.setString(6, getObservação());
          
          statement.execute();
          statement.close();
          
            
                
                
       } catch(SQLException e1){
        e1.printStackTrace();
    }
       JOptionPane.showMessageDialog(null,"Agendado com Sucesso ");
     
        
        
     




    
}

}